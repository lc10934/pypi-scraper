This module is an abstract module. You can configure Barcode Rule, but to
enable this feature, you need to install an extra module for a given model.
This repository provide 'barcodes_generator_product' and
'barcodes_generator_partner' module to generate barcode for product or partner
model.

Alternatively, you can develop a custom module for a custom model. See
'Inheritance' parts.
