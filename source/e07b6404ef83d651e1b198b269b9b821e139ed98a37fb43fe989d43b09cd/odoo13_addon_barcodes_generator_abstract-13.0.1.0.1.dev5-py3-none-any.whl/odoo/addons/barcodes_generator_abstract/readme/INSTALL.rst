This module use an extra python library named 'python-barcode' you should install
to make barcode generation works properly.

``sudo pip install python-barcode``
