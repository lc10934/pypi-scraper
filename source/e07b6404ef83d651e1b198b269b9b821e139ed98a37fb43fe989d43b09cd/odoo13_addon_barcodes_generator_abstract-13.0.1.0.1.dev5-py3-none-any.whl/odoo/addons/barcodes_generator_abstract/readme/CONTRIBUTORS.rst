* Sylvain LE GAL (https://twitter.com/legalsylvain)
* Dave Lasley <dave@laslabs.com>
* `Tecnativa <https://www.tecnativa.com>`__:

  * Carlos Roca
