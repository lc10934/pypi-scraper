from madara.app import Madara

app = Madara()
