from fugue_sql_antlr._parser.sa_fugue_sql import USE_CPP_IMPLEMENTATION

FUGUE_SQL_CPP_PARSER_AVAILABLE = USE_CPP_IMPLEMENTATION
FUGUE_CONF_SQL_IGNORE_CASE = "fugue.sql.compile.ignore_case"
FUGUE_CONF_SQL_PARSER = "fugue.sql.compile.parser"
_FUGUE_SQL_CASE_ISSUE_THREHOLD = 0.8
