
// Generated from fugue_sql.g4 by ANTLR 4.10.1


#include "fugue_sqlBaseVisitor.h"


