import setuptools

setuptools.setup(
    name="datahub_extras",
    version="0.0.1",
    author="Hugh Nguyen",
    description="This package extends datahub and makes it easier to interact with datahub APIs",
    packages=["datahub_extras"]
)