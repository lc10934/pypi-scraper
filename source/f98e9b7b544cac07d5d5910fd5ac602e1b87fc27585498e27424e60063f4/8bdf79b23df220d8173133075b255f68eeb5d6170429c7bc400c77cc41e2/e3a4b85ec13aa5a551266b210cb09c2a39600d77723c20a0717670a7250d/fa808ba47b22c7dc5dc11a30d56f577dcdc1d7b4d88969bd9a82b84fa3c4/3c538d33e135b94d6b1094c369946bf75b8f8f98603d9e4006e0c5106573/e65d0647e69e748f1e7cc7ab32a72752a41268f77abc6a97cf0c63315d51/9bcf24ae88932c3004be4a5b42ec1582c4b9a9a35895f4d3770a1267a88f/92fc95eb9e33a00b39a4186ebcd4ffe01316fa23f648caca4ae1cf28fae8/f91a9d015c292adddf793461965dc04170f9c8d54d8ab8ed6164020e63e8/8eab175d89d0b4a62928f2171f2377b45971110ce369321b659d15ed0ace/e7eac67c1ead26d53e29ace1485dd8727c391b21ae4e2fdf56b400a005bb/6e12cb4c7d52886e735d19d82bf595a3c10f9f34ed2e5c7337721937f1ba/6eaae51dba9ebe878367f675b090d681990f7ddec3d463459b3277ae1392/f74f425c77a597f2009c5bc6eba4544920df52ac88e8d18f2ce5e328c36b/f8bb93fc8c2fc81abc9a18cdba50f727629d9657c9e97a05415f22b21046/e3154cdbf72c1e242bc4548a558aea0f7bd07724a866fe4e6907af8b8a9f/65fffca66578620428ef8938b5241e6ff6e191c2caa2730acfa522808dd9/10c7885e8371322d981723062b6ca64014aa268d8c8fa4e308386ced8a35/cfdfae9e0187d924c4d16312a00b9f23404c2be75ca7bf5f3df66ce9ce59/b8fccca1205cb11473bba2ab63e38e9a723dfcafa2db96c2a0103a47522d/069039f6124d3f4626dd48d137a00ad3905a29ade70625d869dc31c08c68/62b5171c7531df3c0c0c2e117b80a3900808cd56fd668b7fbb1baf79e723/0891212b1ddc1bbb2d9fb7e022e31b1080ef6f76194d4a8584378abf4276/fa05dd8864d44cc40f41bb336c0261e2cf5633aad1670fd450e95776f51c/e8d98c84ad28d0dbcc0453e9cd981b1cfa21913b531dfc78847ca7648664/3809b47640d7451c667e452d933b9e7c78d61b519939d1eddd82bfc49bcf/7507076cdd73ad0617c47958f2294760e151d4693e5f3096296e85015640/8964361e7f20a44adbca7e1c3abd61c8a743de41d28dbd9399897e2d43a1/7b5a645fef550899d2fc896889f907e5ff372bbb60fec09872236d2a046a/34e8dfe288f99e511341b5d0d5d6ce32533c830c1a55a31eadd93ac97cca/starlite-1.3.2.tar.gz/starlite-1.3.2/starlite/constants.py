REDIRECT_STATUS_CODES = [301, 302, 303, 307, 308]
RESERVED_KWARGS = ["state", "headers", "cookies", "request", "socket", "data", "query"]
