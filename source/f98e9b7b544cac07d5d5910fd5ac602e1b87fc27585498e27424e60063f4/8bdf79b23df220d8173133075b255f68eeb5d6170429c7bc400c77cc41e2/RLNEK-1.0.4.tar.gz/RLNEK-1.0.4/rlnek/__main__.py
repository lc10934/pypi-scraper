# -*- coding: utf-8 -*-
"""
Created on Wed Apr 27 17:00:13 2022

@author: Allison
"""

import os

os.system('NTOptimization.py')