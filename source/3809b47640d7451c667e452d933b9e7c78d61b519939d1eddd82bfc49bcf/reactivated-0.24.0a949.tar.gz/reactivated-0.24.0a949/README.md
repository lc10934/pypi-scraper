# Zero-configuration Django and React. Together at last.

Reactivated is the easiest way to use Django and React together.

You get the full power of Django. Rendered by React

No webpack, no config, no tooling. Just React and Django.

https://www.reactivated.io
