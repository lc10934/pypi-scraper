"""Init."""
__version__ = "0.1.0"
from .scrape_glosbe_dict import scrape_glosbe_dict

__all__ = ("scrape_glosbe_dict",)
