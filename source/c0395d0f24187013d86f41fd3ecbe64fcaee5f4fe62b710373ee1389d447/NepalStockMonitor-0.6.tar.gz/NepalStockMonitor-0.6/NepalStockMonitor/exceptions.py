class StockMonitorError(Exception):
    '''Root class to raise error'''

    pass


class CompanyNotFoundError(StockMonitorError):
    '''When user tries to get the company details that does
       not exists'''

    pass


class ConnectionError(StockMonitorError):
    '''When user tries to get the company details when user
       is not connected to internet'''

    pass
