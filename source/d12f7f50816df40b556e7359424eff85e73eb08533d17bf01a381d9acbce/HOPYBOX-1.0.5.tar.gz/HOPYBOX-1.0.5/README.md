# HOPYBOX
This is an open source, practical command Python box

This is an open source, practical command Python box
I named this box "HOPYBOX"
This box contains a number of useful features that can help you use your device more easily with instructions
All you need to do is enter a line of simple instructions that the box contains

## Installation method
pip install HOPYBOX                        
pip install -U HOPYBOX

## Import method
import hopybox

## usage method
See help built in the program