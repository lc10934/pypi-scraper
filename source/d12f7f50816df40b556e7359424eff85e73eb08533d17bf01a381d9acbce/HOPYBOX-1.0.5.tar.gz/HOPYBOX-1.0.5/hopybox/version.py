from platform import system,python_version
version_number = 105
version = 'HOPYBOX 1.0.5 (default, May 8 2022, 12:24:56)\n[Python {}] on {}\nType "help" or "license" for more information'.format(python_version(),system())