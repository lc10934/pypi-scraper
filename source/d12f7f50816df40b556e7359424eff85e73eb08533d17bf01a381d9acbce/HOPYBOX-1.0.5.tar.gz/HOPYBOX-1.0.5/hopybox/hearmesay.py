class Codesay:
  say_thanks = 'Listen to me say thank you, because of you, warm the four seasons, thank you, thank you, the world is more beautiful, I want to thank you, because of you, love is always in the heart, thank you, thank you for passing happiness'
  say_thanks_Chinese = '听我说谢谢你,因为有你,温暖了四季,谢谢你,感谢有你,世界更美丽,我要谢谢你,因为有你,爱常在心底,谢谢你,感谢有你把幸福传递'
  @property
  def listenmesay1(self):
    print(self.say_thanks)
  def listenmesay2(self):
    print(self.say_thanks_Chinese)