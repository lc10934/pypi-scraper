This module extends barcode reader GS1 interface module to allow to read
expiry dates.

The AI's implemented are 15(Preferred consumption date), 17(Expiry date).
