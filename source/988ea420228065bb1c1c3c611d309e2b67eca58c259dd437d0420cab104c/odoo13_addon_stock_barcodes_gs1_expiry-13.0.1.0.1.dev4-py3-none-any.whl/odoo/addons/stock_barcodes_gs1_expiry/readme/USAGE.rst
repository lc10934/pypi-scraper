Read usage section from stock_barcodes module.
