from .google_sheet import GoogleSheetConnection
from .rest_api import RestApiConnection
from .sql_db import SQLDatabaseConnection