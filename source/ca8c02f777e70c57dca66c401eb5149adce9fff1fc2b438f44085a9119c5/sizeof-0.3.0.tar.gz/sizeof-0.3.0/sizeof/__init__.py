"""Gives users direct access to the function."""
from sizeof.sizeof import sizeof, arch
