class InquiryTrinoException(Exception):
	pass
