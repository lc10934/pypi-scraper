This module extends barcode reader interface to allow to read GS1 barcodes.

The AI's implemented are 01(Group), 02(Product), 37(Quantity) and 10(Lots).
