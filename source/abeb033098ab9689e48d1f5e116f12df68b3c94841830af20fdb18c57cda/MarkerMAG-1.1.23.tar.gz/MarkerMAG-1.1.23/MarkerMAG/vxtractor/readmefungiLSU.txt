This software will not extract the 5.8S which is - or was - a part of eukaryote nLSU. The software adresses the nLSU immediately after the 3' end of ITS2.

Default notation of the software:

V1:  The very start of LSU up to, but not including, D1
V2:  The D1 region
V3:  The D2 region
V4:  The D3 region
V5:  The D4 region
V6:  The D5 region
V7:  The D6 region
V8:  The D7a region
V9:  The D7b region
V10: The D8 region
V11: The D10 region. Note: the 5' HMM is very short - 24/23 bp - which is not ideal. It cannot be extened however for lack of conserved sequence data.
V12: The (nested) D9 region
V13: The D11 region
V14: The D12 region
V15: D12 through the very end of nLSU





Reference for the D ("expansion segment") regions: 

AUTHORS   Hassouna,N., Michot,B. and Bachellerie,J.P.
TITLE     The complete nucleotide sequence of mouse 28S rRNA gene.
          Implications for the process of size increase of the large subunit
          rRNA in higher eukaryotes
JOURNAL   Nucleic Acids Res. 12 (8), 3563-3583 (1984)
