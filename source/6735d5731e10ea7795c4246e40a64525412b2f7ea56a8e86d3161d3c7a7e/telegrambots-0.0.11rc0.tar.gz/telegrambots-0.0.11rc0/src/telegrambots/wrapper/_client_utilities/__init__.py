from .client_targetable import ClientTargetable

__all__ = ['ClientTargetable']
