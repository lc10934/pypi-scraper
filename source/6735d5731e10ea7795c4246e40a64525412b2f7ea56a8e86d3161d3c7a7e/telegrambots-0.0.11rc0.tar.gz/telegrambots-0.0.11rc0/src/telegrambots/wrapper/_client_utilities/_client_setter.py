class ClientSetter:
    """
    This class is used to set the client attribute of the TelegramBot object.
    """
