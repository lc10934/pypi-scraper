import os

__version__ = "2022.05.08"

db_path = os.path.join(os.path.dirname(__file__), "db/Geoacumen-Country.mmdb")
