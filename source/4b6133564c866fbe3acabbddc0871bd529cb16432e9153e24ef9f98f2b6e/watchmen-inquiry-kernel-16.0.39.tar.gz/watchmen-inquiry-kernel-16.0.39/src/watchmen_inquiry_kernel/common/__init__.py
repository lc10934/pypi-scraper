from .exception import InquiryKernelException
from .settings import ask_trino_enabled, ask_use_storage_directly
