class InquiryKernelException(Exception):
	pass
