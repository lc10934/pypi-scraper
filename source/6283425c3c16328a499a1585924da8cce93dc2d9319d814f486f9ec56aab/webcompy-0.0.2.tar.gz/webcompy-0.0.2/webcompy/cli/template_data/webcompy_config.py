from webcompy.cli import WebComPyConfig

config = WebComPyConfig(
    app_package="app",
    base="/WebComPy"
)
