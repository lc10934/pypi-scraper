from webcompy.exception import WebComPyException


class WebComPyCliException(WebComPyException):
    pass
