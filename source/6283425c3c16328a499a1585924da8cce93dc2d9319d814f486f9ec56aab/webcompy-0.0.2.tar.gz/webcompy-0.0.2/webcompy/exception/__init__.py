class WebComPyException(Exception):
    pass


__all__ = ["WebComPyException"]
