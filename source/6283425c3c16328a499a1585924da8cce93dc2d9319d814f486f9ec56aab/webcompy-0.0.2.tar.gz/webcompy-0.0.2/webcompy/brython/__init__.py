from webcompy.brython._modules import browser
from webcompy.brython._typing._dom_objs import DOMNode, DOMEvent

__all__ = ["browser", "DOMNode", "DOMEvent"]
