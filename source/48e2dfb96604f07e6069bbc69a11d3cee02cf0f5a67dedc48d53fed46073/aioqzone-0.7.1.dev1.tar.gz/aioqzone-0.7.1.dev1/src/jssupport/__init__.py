"""
A package to support executing NodeJs code in Python.
Mainly for handling JS response from Qzone API.
"""
VERSION = "3.0.0.dev0"
