"aioqzone interface defination"
