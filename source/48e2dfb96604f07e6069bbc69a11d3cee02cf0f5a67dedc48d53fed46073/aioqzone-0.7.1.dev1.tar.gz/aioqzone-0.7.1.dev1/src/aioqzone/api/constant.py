feeds3_html_more = "/proxy/domain/ic2.qzone.qq.com/cgi-bin/feeds/feeds3_html_more"
emotion_getcomments = "/proxy/domain/taotao.qzone.qq.com/cgi-bin/emotion_cgi_ic_getcomments"
emotion_msgdetail = "/proxy/domain/taotao.qq.com/cgi-bin/emotion_cgi_msgdetail_v6"
get_feeds_count = "/proxy/domain/ic2.qzone.qq.com/cgi-bin/feeds/cgi_get_feeds_count.cgi"
internal_dolike_app = "/proxy/domain/w.qzone.qq.com/cgi-bin/likes/internal_dolike_app"
internal_unlike_app = "/proxy/domain/w.qzone.qq.com/cgi-bin/likes/internal_unlike_app"
floatview_photo_list = "/proxy/domain/plist.photo.qq.com/fcgi-bin/cgi_floatview_photo_list_v2"
emotion_msglist = "/proxy/domain/taotao.qq.com/cgi-bin/emotion_cgi_msglist_v6"
emotion_publish = "/proxy/domain/taotao.qzone.qq.com/cgi-bin/emotion_cgi_publish_v6"
emotion_delete = "/proxy/domain/taotao.qzone.qq.com/cgi-bin/emotion_cgi_delete_v6"
emotion_update = (
    "https://user.qzone.qq.com/proxy/domain/taotao.qzone.qq.com/cgi-bin/emotion_cgi_update"
)
