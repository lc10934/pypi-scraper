"""
QQQR is a simulation of Qzone web login process. Including QR login and password login.
A captcha verifier is also contained to pass TDC.
"""

VERSION = "3.1.0a0.dev0"
