'''
这是一个用来改善Python终端输出的默认颜色
（黑色、白色）.让你的文字更加好看、想要突
出的地方更加明显！
This is a default color (black, white)
used to improve Python terminal output.
Make your words more beautiful and the
places you want to highlight more obvious!
'''