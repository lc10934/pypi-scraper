#!/usr/bin/env python3
# HAGrid Version
__version__ = "0.2.39"

if __name__ == "__main__":
    print(__version__)
