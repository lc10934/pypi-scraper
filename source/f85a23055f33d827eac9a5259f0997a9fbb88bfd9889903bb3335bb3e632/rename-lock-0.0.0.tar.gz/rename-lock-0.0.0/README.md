# rename_lock

下の方に日本語の説明があります

## Overview
- Easy file exclusive locking tool based on file rename.
- description is under construction

## Usage
```python
# under construction
```

## 概要
- 手軽なファイルの排他ロックツール
	- ファイルの名称変更を動作原理とする
- 説明は執筆中です

## 使用例
```python
# 執筆中
```
