
# Easy file exclusive locking tool [rename_lock]

import sys
from sout import sout
from ezpip import load_develop
# Easy file exclusive locking tool [rename_lock]
rename_lock = load_develop("rename_lock", "../", develop_flag = True)

