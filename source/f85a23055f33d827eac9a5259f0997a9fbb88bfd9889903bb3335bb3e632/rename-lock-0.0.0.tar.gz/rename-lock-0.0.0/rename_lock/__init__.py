
# Easy file exclusive locking tool [rename_lock]

import os
import sys
import fies
import random
from sout import sout
