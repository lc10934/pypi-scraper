

from asyncore import file_dispatcher
from typing import AsyncGenerator, TextIO, Tuple
import os

from appbridge.prototol import Msg, Action
from appbridge.progress_bar import TranferBar

async def all_file_paths_generator(dir_or_file) -> AsyncGenerator[str, None]:
    # print("test %s" % dir_or_file)
    if os.path.isfile(dir_or_file):
        yield dir_or_file

    elif os.path.isdir(dir_or_file):
        for item in os.listdir(dir_or_file):
            async for p in all_file_paths_generator('%s/%s' % (dir_or_file, item)):
                yield p
    else:
        raise Exception("%s Not found!" % dir_or_file)

async def file_generator(dir, related_path) -> AsyncGenerator[bytes, None]:
        the_path = os.path.join(dir, related_path) #'%s/%s/'%(dir, related_path) if dir != '' else related_path
        print("Will Generate files from \"%s\"" % the_path)

        if os.path.isdir(the_path):
            resp = Msg(Action.ReplyDirInfo, [related_path])
            yield resp.toBytes()

        async for file_path in all_file_paths_generator(the_path):
            
            print("File: %s" % file_path)
            # file_related_path = os.path.basename(filepath)
            file_size = os.path.getsize(file_path)
            # print("file size = %d" % file_size)
            bar = TranferBar('Sending', max=file_size)

            if file_path == the_path:
                # single file
                file_name = os.path.basename(related_path)
                resp = Msg(Action.ReplyFileInfo, [file_name, file_size])
                yield resp.toBytes()
            else:
                # file in dir
                file_name = os.path.relpath(file_path, the_path)
                # file_name = file_path.replace(the_path, '')
                resp = Msg(Action.ReplyFileInfo, [file_name, file_size])
                yield resp.toBytes()

            # print("File: \"%s\"" % file_path)
            file = open(file_path, 'rb')
            while True:
                part = file.read(1024*1024)
                if len(part) <= 0:
                    break
                bar.next(len(part))
                yield part

            bar.finish()
            file.close()
            # print("one file complete!")
            # msg = Msg(Action.ResponseOneFileComplete, [])
            # yield msg.toBytes()

        msg = Msg(Action.ReplyAllFilesEnd, [])
        yield msg.toBytes()


def prepare_receive_file(rpath: str, save_dir: str) -> Tuple[TextIO, int]:
    # file_path = msg.params[0]
    # file_related_path = msg.params[1]
    # file_remote_path =  os.path.join(file_dir, file_related_path)
    # file_path = file_remote_path
    # size = msg.params[1]

    filedir = os.path.dirname(file_path)
    # filename = os.path.basename(file_path)

    if not os.path.isdir(filedir):
        os.makedirs(dir, 0o755)


    # if filedir == '':
    #     # single file
    #     file_path = os.path.join(save_dir, os.path.basename(file_path))
    # else:
    #     # file in dir, should mkdir
    #     file_path = os.path.join(save_dir, file_path)
    #     dir = os.path.dirname(file_path)
    #     if not os.path.isdir(dir):
    #         os.makedirs(dir, 0o755)
    
    local_filepath = os.path.join(save_dir, )
    print("Will receive file: %s" % file_path)
    return open(file_path, 'wb'), size


# def try_receive_file_data(data, file, receive_size, total_size):

#     # receive part bytes a file
#     file.write(data)
#     # remain_size -= len(data)
#     # received = total_size - remain_size
#     receive_size += len(data)
#     # print("Receiving... %d/%d %.2f%%" % (
#     #     receive_size, 
#     #     total_size, 
#     #     receive_size / total_size * 100))


   
        
#     return (file, receive_size, total_size)