# Apple Data resource package

This package contains static assets from <https://docs.hackdiffe.rent>

The contents of the `_data` folder are included in `share/`