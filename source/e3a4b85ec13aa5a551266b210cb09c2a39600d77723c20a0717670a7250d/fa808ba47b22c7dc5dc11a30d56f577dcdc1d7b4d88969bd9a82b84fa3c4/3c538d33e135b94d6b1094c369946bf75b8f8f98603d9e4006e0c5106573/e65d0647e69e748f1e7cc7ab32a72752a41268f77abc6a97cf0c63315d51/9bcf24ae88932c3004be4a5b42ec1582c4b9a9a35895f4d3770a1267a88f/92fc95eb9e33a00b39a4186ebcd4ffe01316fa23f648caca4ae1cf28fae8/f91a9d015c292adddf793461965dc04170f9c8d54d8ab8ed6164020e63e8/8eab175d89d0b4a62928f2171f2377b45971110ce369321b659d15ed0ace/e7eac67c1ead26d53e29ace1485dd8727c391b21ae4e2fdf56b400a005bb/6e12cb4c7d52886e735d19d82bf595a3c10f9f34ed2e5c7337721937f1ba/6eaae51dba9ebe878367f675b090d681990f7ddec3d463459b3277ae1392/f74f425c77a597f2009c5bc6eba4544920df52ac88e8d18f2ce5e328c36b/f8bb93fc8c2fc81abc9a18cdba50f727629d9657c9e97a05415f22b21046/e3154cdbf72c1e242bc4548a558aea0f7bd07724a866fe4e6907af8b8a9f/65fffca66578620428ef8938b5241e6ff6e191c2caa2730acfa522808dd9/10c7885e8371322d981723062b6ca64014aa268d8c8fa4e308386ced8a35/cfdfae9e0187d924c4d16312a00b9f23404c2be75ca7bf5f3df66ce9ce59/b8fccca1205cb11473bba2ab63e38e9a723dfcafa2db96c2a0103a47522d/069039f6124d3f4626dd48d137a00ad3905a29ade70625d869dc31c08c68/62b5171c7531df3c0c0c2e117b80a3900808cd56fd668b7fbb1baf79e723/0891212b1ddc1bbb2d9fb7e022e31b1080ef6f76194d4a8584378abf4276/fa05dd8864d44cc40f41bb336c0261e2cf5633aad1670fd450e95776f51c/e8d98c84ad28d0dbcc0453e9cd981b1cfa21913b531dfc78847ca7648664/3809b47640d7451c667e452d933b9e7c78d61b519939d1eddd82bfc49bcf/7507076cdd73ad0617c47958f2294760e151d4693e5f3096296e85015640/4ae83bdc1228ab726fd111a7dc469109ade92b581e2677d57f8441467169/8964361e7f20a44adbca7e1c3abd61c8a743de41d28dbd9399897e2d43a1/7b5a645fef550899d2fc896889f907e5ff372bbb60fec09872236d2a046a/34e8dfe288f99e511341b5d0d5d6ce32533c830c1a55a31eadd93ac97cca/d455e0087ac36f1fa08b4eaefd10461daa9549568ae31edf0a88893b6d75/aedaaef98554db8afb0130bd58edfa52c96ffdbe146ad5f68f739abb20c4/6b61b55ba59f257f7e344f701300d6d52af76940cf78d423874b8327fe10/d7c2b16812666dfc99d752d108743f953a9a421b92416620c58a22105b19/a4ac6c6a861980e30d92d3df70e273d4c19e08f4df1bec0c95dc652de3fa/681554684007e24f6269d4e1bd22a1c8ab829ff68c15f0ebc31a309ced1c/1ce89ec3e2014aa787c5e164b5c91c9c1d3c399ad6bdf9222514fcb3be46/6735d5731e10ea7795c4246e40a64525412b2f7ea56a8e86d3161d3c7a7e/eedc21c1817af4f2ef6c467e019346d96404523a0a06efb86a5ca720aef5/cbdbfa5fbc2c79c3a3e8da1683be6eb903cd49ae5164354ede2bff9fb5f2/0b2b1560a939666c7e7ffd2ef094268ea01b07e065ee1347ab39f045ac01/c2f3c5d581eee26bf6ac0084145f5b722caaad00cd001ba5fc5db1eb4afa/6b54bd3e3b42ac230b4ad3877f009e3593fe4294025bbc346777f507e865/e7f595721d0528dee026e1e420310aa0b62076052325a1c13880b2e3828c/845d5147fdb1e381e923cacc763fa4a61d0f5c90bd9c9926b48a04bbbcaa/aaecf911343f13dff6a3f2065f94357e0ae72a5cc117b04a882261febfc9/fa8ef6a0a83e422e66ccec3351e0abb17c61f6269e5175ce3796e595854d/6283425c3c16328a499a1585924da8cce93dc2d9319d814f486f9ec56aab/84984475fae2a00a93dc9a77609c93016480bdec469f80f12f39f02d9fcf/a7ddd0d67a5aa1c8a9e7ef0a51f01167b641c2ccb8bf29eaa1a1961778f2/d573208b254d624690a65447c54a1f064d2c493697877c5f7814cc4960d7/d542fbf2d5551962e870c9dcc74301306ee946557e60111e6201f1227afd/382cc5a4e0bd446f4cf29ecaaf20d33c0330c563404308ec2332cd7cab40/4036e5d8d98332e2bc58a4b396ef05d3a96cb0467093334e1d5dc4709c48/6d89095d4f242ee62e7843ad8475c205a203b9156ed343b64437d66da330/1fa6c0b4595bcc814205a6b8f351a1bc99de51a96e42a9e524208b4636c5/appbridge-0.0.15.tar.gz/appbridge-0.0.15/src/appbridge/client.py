
import asyncio
from asyncio import Event
from typing import AsyncGenerator, Tuple, Optional

from rsocket.payload import Payload
from rsocket.transports.aiohttp_websocket import websocket_client

from appbridge import bonjour, channel, common
from appbridge.prototol import Msg, Action
from appbridge.progress_bar import TranferBar

def get_service_ip_port(service_name: str) -> Optional[Tuple[str, str]]: 
    info = bonjour.get_service_info(service_name)
    if info is None:
        print("can't find service %s" % service_name)
        return None
    (ip, port) = bonjour.get_ip_port(info)
    # print("service address: %s%d" % ('ws://' + ip + ':', port))

    return (ip, port)


async def do_request(service_name, msg: Msg):
    (ip, port) = get_service_ip_port(service_name)
    # print("reqest data: %s" % msg.toString())
    async with websocket_client('http://%s:%d' % (ip, port)) as client:

        (publisher, subscriber) = channel.create(msg)

        requested = client.request_channel(Payload(msg.toBytes()), publisher)
        requested.initial_request_n(1).subscribe(subscriber)

        await subscriber.channel_complete_event.wait()
        # print('channel done!')

    # print('do_request done!')


async def do_request_info(service_name):
    (ip, port) = get_service_ip_port(service_name)
    msg = Msg(Action.GetInfo, [])
    # print("reqest data: %s" % msg.toString())
    async with websocket_client('http://%s:%d' % (ip, port)) as client:
        result = await client.request_response(Payload(msg.toBytes()))
        ret = Msg.fromBytes(result.data)
        print("Service Supported Actions:")
        for item in ret.params:
            print("\t%s" % item)


def request(service_name, action, params):
    msg = Msg(action, params)
    asyncio.run(do_request(service_name, msg))
    # print("request done")

def request_info(service_name):
    asyncio.run(do_request_info(service_name))
    # print("request done")
