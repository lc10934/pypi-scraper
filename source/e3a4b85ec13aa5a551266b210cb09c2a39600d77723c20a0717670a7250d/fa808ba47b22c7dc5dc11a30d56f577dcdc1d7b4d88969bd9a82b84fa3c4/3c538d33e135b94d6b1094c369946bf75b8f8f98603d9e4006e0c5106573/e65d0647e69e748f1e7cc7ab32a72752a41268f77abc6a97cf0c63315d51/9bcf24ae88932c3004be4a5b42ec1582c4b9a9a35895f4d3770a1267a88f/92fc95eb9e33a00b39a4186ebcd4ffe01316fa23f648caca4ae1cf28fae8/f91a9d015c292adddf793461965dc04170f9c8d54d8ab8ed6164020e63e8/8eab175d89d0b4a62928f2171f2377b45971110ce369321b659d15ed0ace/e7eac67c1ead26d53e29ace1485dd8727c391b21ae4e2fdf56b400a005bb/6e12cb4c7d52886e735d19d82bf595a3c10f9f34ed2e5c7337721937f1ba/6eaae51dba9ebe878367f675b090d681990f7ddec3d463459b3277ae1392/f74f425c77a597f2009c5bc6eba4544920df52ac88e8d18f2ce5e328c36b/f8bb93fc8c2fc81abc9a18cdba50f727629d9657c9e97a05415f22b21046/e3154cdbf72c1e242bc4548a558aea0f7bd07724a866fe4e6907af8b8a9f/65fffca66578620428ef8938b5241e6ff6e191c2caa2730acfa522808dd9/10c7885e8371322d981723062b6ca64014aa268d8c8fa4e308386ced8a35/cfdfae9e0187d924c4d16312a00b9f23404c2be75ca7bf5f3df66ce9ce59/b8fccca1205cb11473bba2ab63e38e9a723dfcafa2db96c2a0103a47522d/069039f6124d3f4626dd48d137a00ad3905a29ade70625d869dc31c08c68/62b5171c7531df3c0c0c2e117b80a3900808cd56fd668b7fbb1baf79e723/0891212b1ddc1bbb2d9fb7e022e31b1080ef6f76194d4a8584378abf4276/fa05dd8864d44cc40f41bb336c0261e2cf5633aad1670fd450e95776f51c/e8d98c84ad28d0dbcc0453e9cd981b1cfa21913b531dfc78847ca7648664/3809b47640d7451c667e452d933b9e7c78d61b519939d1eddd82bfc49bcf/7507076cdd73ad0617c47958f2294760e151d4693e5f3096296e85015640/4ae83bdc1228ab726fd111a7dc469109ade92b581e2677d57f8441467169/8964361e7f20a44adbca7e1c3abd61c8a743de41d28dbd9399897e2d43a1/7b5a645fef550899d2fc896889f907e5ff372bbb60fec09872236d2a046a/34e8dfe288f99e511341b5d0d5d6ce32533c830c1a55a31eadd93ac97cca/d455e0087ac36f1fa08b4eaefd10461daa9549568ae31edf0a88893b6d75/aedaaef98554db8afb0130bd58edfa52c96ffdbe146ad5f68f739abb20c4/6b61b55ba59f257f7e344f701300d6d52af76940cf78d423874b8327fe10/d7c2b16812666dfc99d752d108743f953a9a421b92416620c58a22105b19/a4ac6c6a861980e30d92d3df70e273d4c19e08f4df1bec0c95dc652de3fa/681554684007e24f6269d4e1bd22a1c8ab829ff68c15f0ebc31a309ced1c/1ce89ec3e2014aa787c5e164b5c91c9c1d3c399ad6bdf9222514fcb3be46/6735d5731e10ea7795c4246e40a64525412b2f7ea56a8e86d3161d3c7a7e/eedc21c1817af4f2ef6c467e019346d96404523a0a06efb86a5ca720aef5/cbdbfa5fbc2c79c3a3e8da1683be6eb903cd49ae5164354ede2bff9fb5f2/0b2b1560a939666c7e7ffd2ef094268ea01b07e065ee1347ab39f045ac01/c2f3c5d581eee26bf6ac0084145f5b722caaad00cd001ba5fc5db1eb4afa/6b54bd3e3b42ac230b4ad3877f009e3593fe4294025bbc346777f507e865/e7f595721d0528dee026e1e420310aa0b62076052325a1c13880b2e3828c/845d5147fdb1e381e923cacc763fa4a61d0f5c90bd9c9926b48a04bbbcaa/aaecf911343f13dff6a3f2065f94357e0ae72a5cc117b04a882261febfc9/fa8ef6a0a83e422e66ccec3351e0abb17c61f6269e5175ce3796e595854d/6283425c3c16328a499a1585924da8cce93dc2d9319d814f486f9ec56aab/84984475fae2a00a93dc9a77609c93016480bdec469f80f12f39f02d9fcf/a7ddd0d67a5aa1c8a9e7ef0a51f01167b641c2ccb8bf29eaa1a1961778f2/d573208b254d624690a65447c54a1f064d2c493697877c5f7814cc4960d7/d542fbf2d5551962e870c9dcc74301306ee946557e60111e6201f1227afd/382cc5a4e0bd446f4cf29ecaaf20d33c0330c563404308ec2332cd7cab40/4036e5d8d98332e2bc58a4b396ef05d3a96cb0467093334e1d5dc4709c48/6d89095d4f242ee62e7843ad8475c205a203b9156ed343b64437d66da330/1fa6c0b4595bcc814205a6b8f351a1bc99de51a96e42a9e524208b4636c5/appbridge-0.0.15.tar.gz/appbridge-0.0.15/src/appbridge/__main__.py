
import sys
from appbridge import bonjour, server, client

import pkg_resources
version = pkg_resources.require("appbridge")[0].version


def main():
    args = sys.argv[1:]
    argslen = len(args)
    # no params
    if argslen == 0:
        bonjour.discover_service()
        return

    # -h
    if args[0] == '-h':
        print("appbridge v%s" % version)
        return

    # -s <service_name> [<service_dir>] [-f <files_dir>]
    if args[0] == '-s':
        service_name = args[1]
        service_dir = ''
        files_dir = ''
        if argslen > 2 :
            flag = args[2]
            if flag == '-f':
                files_dir = args[3]
            else:
                service_dir = flag
                if argslen > 3 and args[3] == '-f':
                    files_dir = args[4]

        server.start_service(service_name, service_dir, files_dir)
        return

    # <service_name> [ <function> [<params...>] ]
    service_name = args[0]
    if argslen == 1:
        client.request_info(service_name)
    else:
        action = args[1]
        params = args[2:]
        client.request(service_name, action, params)


if __name__ == '__main__':
    main()