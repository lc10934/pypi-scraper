# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['appbridge']

package_data = \
{'': ['*']}

install_requires = \
['aiohttp>=3.8.1,<4.0.0',
 'progress>=1.6,<2.0',
 'quart>=0.17.0,<0.18.0',
 'rsocket>=0.3,<0.4',
 'zeroconf>=0.38.5,<0.39.0']

entry_points = \
{'console_scripts': ['appbridge = appbridge.__main__:main']}

setup_kwargs = {
    'name': 'appbridge',
    'version': '0.0.15',
    'description': 'Discoverable service in local networking!',
    'long_description': None,
    'author': 'yudingp',
    'author_email': 'yudingp@163.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
