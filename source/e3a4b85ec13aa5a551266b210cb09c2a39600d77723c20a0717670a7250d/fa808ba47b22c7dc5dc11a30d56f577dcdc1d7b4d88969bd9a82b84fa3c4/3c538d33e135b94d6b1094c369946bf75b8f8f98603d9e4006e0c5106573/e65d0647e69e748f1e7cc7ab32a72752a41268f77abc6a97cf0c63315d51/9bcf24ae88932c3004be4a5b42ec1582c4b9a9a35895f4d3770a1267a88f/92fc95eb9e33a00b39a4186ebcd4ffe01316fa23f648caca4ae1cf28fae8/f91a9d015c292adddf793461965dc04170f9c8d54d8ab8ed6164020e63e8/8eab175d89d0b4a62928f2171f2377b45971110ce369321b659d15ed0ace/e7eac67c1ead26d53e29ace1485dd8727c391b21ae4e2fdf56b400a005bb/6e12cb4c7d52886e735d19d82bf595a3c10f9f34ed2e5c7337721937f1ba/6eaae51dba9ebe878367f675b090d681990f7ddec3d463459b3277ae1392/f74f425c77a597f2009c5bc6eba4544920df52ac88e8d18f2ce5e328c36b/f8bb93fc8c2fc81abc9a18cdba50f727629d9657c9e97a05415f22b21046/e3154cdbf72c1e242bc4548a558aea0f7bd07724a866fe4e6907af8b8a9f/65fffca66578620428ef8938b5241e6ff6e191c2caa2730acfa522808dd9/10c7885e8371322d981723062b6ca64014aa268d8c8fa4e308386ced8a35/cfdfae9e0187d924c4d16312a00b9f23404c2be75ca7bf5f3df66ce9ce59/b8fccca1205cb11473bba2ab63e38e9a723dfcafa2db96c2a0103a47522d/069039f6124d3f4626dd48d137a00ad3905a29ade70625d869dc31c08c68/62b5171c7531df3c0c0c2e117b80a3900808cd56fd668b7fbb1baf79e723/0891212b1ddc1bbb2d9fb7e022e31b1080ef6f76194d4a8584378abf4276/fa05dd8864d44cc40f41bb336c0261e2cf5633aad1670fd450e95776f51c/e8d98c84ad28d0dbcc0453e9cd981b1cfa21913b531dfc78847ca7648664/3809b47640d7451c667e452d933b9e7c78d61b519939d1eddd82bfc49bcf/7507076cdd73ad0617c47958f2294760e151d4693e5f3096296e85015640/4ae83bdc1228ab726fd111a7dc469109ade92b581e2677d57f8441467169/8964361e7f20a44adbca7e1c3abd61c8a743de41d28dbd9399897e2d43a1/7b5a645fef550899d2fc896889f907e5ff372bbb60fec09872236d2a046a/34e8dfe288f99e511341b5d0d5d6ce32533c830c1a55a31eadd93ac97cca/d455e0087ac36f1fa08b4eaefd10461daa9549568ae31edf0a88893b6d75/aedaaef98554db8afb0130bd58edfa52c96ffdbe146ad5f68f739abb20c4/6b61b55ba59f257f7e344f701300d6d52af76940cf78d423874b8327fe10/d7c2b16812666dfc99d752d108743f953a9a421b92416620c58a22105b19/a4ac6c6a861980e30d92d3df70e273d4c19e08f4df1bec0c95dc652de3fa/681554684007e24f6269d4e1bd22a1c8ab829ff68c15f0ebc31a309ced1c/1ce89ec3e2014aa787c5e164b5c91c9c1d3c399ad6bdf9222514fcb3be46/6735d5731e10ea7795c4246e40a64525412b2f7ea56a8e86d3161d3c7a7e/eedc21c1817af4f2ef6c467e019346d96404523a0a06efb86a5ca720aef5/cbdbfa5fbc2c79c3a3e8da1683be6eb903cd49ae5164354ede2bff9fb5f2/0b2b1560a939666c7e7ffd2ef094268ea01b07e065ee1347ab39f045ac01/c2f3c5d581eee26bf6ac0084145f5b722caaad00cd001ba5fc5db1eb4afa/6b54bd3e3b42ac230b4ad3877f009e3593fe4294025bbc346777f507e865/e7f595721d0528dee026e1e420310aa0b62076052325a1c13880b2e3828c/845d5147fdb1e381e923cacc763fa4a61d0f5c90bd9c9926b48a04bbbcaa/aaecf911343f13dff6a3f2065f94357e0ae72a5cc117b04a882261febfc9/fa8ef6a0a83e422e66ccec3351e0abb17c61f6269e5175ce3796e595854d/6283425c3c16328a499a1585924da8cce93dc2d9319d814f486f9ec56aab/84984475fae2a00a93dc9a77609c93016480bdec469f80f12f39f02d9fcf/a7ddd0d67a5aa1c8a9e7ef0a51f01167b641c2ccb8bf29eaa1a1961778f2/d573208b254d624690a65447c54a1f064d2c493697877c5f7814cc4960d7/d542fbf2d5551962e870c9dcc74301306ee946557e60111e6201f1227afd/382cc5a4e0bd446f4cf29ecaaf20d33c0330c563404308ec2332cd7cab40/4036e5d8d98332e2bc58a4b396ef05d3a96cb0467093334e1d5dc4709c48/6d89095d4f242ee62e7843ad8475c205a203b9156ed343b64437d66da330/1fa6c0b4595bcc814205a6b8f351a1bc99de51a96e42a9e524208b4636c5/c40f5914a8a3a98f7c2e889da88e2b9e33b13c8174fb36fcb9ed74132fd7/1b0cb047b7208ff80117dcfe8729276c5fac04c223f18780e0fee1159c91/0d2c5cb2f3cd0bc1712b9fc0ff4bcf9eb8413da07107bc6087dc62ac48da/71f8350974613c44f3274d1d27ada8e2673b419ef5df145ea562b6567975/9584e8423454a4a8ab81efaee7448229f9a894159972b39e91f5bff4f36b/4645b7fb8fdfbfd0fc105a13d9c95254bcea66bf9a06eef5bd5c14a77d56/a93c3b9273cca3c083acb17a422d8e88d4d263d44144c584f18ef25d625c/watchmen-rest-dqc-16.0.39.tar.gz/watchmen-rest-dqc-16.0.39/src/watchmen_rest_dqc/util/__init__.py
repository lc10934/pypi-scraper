from .trans import trans, trans_readonly, trans_with_fail_over, trans_with_tail
