# flask-classful-apispec
Automatic api docs generation for flask classful based on apispec
