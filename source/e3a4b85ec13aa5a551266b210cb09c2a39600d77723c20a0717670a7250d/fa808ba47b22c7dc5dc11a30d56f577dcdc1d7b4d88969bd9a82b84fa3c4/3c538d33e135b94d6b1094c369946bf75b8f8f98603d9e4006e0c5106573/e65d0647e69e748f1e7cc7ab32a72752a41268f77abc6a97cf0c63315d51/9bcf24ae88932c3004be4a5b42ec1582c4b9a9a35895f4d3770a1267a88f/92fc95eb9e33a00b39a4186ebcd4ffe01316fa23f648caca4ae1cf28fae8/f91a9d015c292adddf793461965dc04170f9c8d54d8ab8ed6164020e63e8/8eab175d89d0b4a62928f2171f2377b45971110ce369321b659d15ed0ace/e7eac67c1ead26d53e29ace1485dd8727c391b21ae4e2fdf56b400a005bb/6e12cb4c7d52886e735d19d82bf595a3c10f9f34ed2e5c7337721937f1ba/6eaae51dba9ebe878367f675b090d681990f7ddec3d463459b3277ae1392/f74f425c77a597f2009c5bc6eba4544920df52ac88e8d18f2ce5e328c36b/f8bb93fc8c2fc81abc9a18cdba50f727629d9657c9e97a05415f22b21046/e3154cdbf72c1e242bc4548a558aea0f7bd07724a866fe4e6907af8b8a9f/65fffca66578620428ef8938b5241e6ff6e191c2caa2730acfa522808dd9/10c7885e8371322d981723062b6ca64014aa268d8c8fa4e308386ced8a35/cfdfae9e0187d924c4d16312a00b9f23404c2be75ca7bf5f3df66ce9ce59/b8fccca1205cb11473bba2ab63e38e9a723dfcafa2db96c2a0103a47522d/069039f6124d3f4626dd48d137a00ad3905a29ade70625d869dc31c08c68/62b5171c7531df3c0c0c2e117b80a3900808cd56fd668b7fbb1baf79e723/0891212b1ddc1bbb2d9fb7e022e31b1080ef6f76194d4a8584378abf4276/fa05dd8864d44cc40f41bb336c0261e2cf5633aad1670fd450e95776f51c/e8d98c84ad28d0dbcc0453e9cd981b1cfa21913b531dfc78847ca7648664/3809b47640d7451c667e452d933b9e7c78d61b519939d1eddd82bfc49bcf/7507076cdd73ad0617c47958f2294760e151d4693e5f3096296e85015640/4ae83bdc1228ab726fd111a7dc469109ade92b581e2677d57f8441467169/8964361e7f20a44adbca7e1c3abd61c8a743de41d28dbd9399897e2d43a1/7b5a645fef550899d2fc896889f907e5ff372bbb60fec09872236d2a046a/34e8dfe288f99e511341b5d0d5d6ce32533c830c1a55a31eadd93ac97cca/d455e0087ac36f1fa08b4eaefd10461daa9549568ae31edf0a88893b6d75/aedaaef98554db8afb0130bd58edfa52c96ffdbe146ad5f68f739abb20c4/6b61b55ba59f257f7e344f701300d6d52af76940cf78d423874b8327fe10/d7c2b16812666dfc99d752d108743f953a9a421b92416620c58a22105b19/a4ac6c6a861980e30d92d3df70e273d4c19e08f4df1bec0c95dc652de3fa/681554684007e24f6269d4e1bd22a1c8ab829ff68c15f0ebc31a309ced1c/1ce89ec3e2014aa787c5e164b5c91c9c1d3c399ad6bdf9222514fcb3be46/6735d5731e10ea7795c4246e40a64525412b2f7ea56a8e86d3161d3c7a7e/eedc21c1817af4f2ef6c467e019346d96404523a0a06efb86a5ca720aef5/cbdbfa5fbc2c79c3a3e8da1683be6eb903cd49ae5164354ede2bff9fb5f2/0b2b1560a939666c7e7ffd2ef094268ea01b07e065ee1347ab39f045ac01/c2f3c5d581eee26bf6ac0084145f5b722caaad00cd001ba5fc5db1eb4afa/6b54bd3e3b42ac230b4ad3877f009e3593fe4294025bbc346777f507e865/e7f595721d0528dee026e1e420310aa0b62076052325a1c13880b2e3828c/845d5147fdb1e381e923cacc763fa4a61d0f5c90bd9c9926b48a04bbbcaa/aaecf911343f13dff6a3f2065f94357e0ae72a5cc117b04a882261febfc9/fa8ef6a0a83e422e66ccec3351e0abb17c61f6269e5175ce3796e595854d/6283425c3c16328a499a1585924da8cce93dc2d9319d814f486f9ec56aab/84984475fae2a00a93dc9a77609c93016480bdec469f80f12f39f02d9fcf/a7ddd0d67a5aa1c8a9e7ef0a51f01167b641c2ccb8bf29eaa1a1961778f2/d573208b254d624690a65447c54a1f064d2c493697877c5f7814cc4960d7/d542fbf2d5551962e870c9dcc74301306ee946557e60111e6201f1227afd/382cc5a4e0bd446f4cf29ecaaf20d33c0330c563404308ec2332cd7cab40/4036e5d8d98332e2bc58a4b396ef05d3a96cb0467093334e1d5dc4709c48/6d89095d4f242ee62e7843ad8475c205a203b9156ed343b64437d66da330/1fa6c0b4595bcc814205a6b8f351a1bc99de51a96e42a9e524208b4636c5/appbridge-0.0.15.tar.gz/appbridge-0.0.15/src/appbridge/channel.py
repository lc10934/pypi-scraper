
from asyncio import Event
from typing import Callable, List, Tuple, Optional, AsyncGenerator
import os
import importlib.util
import uuid
import shutil

from reactivestreams.publisher import Publisher
from reactivestreams.subscriber import Subscriber
from reactivestreams.subscription import Subscription
from rsocket.streams.stream_from_async_generator import StreamFromAsyncGenerator
from rsocket.fragment import Fragment
from rsocket.payload import Payload

from appbridge.progress_bar import TranferBar
from appbridge.prototol import Msg, Action, RequestFilesCallable
from appbridge import common
from appbridge.config import Config



#
# client request get file list from me
#
# list <path>
#
async def handle_list_action(action: str, params: List[str], 
                            request_files: RequestFilesCallable) -> AsyncGenerator[bytes, None]:
    files = []
    p = ''
    if len(params) > 0:
        p = params[0]
    dir = os.path.join(Config.files_dir, p)
    print('handle list files of %s...', dir)

    for item in os.listdir(dir):
        files.append(os.path.join(p, item))

    yield Msg(Action.ListFile, files).toBytes()

#
# client request get files from me
#
# get <file_path_on_service>
#
async def handle_get_action(action: str, params: List[str], 
                            request_files: RequestFilesCallable) -> AsyncGenerator[bytes, None]:
    p = params[0]
    full_path = os.path.join(Config.files_dir, p)
    norm_path = os.path.normpath(full_path)
    basename = os.path.basename(norm_path)
    dir = os.path.dirname(norm_path)

    # send file to client
    async for e in common.file_generator(dir, basename):
        yield e

#
# client request send files to me
#
# send <file_path_on_client>...
#
async def handle_save_action(action: str, params: List[str], 
                            request_files: RequestFilesCallable) -> AsyncGenerator[bytes, None]:

    # request files from client

    received_files = []
    async for e in request_files(params, received_files):
        yield e

    # save received files to files dir
    if Config.files_dir != '':
        for f in received_files:
            # local_path = os.path.join(session_dir, f)
            filename = os.path.basename(f)
            path_on_files_dir = os.path.join(Config.files_dir, filename)

            if Config.rename_save:
                index = 1
                while os.path.exists(path_on_files_dir):
                    path_on_files_dir = os.path.join(Config.files_dir, str(index) + '_' + filename)
                    index += 1
            
            shutil.move(f, path_on_files_dir)
            print("File saved in: %s" % path_on_files_dir)



class ChannelSubscriber(Subscriber):

    request_file_path: str = ''
    file_received_size: int = 0
    file_total_size: int = 0
    file = None

    # 正在接收的目录名
    received_dirname:str = ''

    # 正在接收的文件完整路径
    received_file: str = ''

    pending_msg: Msg

    session_dir = ''

    finished = False

    def __init__(self, init_msg, is_service) -> None:
        super().__init__()

        self.is_service = is_service

        self.channel_complete_event = Event()
        self.got_file_event = Event()
        self.got_file_event.set()
        self.request_event = Event()

        self.pending_msg = init_msg

        if not is_service:
            # client
            # id = uuid.uuid1()
            # session_dir = os.path.join('sessions' + str(id)) 
            # if not os.path.isdir(session_dir):
            #     os.makedirs(session_dir, 0o755)
            #     print('create session_dir: %s' % session_dir)
            self.session_dir = '.'
        else:
            # on service
            id = uuid.uuid1()
            session_dir = os.path.join(Config.service_dir, 'sessions', str(id)) 
            if not os.path.isdir(session_dir):
                os.makedirs(session_dir, 0o755)
                print('create session_dir: %s' % session_dir)

            self.session_dir = session_dir
            self.request_event.set()
        
        print('[+] Channel subscriber init')


    def __del__(self):

        if self.finished:
            print('This channel already finished!')
            return

        self.finished = True

        self.channel_complete_event.set()

        if self.file:
            self.file.close()
    
        if self.is_service:
            if os.path.isdir(self.session_dir):
                shutil.rmtree(self.session_dir, ignore_errors=True)
                # os.rmdir(self.session_dir)
                print('delete session_dir: %s' % self.session_dir)

        print('[-] Channel subscriber deleted')

    def finish(self):
        self.__del__()

    def on_subscribe(self, subscription: Subscription):
        self.subscription = subscription
        subscription.request(1)

    def on_error(self, exception: Exception):
        print('on_error: ' + str(exception))
        self.finish()

    def on_complete(self):
        print('on_complete')
        self.finish()

    def on_next(self, value: Payload, is_complete=False):

        # print("From client: len=%d, complete=%s" % (len(value.data), "Yes" if is_complete else "No"))

        if not is_complete:
            self.subscription.request(1)

        # complete signal
        datalen = len(value.data)
        if datalen == 0 and is_complete:
            print("on_next: complete empty msg")
            self.finish()
            return

        # handle file receiving
        if self.file_received_size < self.file_total_size:
            self.file.write(value.data)
            self.file_received_size += datalen
            self.bar.next(datalen)

            if self.file_received_size >= self.file_total_size:
                # received complete
                self.file.close()
                self.file = None
                self.file_received_size = 0
                self.file_total_size = 0
                self.bar.finish()
                print("Received a file!")

            return


        # handle msg
        msg = Msg.fromBytes(value.data)
        print('\ngot Msg: %s' % msg.toString())

        if msg.action == Action.GetFile:
            self.pending_msg = msg
            self.request_event.set()

        elif msg.action == Action.ListFile:
            # response of list file
            print("List of files:")
            for item in msg.params:
                print('   %s'%item)
            print()

        elif msg.action == Action.ReplyDirInfo:

            dirname = msg.params[0]
            newpath = os.path.join(self.session_dir, dirname)

            if self.is_service or Config.rename_save:
                index = 0
                while os.path.exists(newpath):
                    index += 1
                    if self.is_service:
                        dirname = os.path.join('__temp_' + str(index), msg.params[0])
                    else:
                        dirname = msg.params[0] + '_' + str(index)
                        
                    newpath = os.path.join(self.session_dir, dirname)

            if not os.path.isdir(newpath):
                os.makedirs(newpath, 0o755)

            self.received_dirname = dirname  # os.path.basename(newpath)

            print("Prepared a received dir! %s" % self.received_dirname)

        elif msg.action == Action.ReplyFileInfo:
            rpath = msg.params[0]
            
            fpath = os.path.join(self.session_dir, self.received_dirname, rpath)

            if self.is_service or Config.rename_save:
                index = 1
                while os.path.exists(fpath):
                    if self.is_service:
                        fpath = os.path.join(self.session_dir, self.received_dirname, '__temp_' + str(index), rpath)
                    else:
                        (rpath1, ext) = os.path.splitext(rpath)
                        fpath = os.path.join(self.session_dir, self.received_dirname, rpath1 + "_" + str(index) + ext)
                    index += 1

            fpath_dir = os.path.dirname(fpath)
            if not os.path.isdir(fpath_dir):
                os.makedirs(fpath_dir, 0o755)

            self.file_total_size = msg.params[1]
            self.file =  open(fpath, 'wb')
            self.received_file = fpath

            # (self.file, self.file_total_size) = common.prepare_receive_file(msg, self.received_path)
            self.file_received_size = 0
            self.bar = TranferBar('Receiving', max=self.file_total_size)
            print("File: %s" % fpath)

        # elif msg.action == Action.ResponseOneFileComplete:
        #     self.file.close()
        #     self.file = None
        #     self.file_received_size = 0
        #     self.file_total_size = 0
        #     self.bar.finish()
        #     print("Received a file!")

        if msg.action == Action.ReplyAllFilesEnd:
            self.got_file_event.set()
        
        if is_complete:
            print("got complete msg to finish")
            self.finish()
        else:
            self.subscription.request(1)


    def publisher(self) -> Publisher:

        async def request_files(files: List[str], received_files: List[str] = []) -> AsyncGenerator[bytes, None]:
            
            print('waiting for pending file got...')
            
            await self.got_file_event.wait()

            print("go on!")

            for f in files:

                self.got_file_event.clear()
                self.received_file = ''
                # self.received_dir = self.session_dir

                # do request files
                req = Msg(Action.GetFile, [f])
                yield req.toBytes()

                # wait for file received
                print('waiting for file...')
                await self.got_file_event.wait()
                print('GOT file!')
                if self.received_dirname:
                    received_files.append(os.path.join(self.session_dir, self.received_dirname))
                else:
                    received_files.append(self.received_file)

        async def generator() -> AsyncGenerator[Tuple[Fragment, bool], None]:

            print('generator start...')

            while True:

                print('waiting for a request...')
                await self.request_event.wait()
                self.request_event.clear()

                print('handle pending msg', self.pending_msg.toString())

                handle_action = None
                action = self.pending_msg.action

                if not self.is_service:
                    # client
                    if action == Action.GetFile:
                        handle_action = handle_get_action
                    elif action == Action.SendFile:
                        handle_action = handle_save_action
                else:
                    # service
                    # find an action handler to handle the action
                    module_file_path = os.path.join(Config.service_dir, action + '.py')
                    module_name = action
                    if Config.service_dir == '' or not os.path.isfile(module_file_path):
                        if Config.files_dir != '':
                            if action == Action.GetFile:
                                handle_action = handle_get_action
                            elif action == Action.SendFile:
                                handle_action = handle_save_action
                            elif action == Action.ListFile:
                                handle_action = handle_list_action      
                    else:
                        print("load %s from %s" % (module_name, module_file_path))
                        module_spec = importlib.util.spec_from_file_location(module_name , module_file_path)
                        module = importlib.util.module_from_spec(module_spec)
                        module_spec.loader.exec_module(module)
                        handle_action = module.handle_action

                if handle_action is None:
                    raise Exception("Don't support action \"%s\"" % action)
    
                async for data in handle_action(action, self.pending_msg.params, request_files):
                    yield Fragment(data), False
        
                # print('end of action handler')
                if self.is_service:
                    # print('go complete!')
                    break

            # print('generator end!')

            self.finish()
            
            # complete
            msg = Msg(Action.Complete, [])
            yield Fragment(msg.toBytes()), True

        return StreamFromAsyncGenerator(generator)


def create(init_msg: Msg|None, is_service = False) -> Tuple[Optional[Publisher], Optional[Subscriber]]:
 
    subscriber = ChannelSubscriber(init_msg, is_service)

    return subscriber.publisher(), subscriber
