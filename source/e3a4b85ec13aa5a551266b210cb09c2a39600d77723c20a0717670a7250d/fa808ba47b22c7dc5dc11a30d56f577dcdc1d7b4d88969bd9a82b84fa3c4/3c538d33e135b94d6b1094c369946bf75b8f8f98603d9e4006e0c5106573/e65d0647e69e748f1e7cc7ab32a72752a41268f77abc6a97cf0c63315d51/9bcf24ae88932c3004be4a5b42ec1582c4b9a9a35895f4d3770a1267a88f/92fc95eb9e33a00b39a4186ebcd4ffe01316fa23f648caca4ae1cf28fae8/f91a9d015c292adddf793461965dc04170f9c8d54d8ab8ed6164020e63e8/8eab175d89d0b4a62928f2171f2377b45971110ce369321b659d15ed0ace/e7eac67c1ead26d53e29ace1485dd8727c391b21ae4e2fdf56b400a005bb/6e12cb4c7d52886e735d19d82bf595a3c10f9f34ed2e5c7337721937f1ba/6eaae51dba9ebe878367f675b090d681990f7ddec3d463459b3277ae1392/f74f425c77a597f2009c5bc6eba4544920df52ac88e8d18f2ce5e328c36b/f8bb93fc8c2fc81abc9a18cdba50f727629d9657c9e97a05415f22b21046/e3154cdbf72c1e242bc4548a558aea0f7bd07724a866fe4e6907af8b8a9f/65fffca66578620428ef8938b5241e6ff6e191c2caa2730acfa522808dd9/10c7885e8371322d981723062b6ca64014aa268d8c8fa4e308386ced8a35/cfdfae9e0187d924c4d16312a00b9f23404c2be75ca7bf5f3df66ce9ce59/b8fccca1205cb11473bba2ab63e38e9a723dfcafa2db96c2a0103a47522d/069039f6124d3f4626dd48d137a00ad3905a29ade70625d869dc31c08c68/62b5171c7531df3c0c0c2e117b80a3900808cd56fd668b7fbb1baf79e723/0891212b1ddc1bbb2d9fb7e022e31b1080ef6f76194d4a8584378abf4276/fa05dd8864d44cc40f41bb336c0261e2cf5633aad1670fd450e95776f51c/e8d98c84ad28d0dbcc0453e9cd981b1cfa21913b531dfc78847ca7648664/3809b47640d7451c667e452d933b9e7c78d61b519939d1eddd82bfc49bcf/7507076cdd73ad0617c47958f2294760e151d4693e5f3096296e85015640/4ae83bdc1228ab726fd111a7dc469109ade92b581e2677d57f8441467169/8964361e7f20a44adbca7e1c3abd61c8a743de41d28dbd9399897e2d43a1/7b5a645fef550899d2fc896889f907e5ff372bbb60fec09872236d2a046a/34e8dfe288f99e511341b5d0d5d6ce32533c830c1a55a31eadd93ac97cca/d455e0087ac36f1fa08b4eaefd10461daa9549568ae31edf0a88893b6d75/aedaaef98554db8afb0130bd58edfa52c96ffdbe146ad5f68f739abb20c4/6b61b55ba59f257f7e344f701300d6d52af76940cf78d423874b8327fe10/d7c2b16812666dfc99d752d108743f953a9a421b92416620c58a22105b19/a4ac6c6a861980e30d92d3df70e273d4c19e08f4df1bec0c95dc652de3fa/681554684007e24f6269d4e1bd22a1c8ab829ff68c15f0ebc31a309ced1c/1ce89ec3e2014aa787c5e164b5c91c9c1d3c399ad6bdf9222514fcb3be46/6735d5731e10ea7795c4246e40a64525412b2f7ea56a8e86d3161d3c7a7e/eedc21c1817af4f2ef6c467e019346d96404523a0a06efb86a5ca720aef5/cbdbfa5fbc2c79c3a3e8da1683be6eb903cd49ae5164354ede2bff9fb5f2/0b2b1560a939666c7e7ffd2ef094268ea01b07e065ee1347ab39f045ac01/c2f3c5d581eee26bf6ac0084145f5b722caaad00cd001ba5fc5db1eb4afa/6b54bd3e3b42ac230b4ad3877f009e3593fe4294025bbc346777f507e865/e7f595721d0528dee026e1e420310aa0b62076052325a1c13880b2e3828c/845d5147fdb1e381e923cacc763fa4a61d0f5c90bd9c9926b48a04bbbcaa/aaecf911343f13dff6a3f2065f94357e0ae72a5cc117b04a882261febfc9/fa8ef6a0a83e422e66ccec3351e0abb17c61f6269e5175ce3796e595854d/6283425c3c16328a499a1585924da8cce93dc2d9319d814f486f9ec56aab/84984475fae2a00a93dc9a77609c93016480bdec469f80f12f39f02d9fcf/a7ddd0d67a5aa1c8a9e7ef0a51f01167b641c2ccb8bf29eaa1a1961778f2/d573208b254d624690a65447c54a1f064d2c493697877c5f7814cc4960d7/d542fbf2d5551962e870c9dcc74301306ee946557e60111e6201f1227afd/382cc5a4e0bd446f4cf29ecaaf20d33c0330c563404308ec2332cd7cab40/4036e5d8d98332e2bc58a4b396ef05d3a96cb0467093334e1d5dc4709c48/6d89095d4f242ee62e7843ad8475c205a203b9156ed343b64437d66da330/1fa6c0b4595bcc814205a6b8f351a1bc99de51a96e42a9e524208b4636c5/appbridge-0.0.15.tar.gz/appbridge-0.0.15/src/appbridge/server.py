

from asyncio import Future
import os
import shutil

from quart import Quart
from typing import Tuple, Optional
from rsocket.helpers import create_future
from rsocket.payload import Payload
from rsocket.request_handler import BaseRequestHandler
from rsocket.transports.quart_websocket import websocket_handler
from reactivestreams.publisher import Publisher
from reactivestreams.subscriber import Subscriber

from appbridge import bonjour, channel
from appbridge.prototol import Action, Msg
from appbridge.config import Config

class Handler(BaseRequestHandler):

    async def request_response(self, payload: Payload) -> Future:
        msg = Msg.fromBytes(payload.data)

        # get service information
        if msg.action == Action.GetInfo:
            ret = Msg('', [])
            if Config.service_dir != '' and os.path.isdir(Config.service_dir):
                for item in os.listdir(Config.service_dir):
                    if item.endswith('.py'):
                        ret.params.append(os.path.splitext(item)[0])
            if Config.files_dir != '':
                ret.params.append(Action.GetFile)
                ret.params.append(Action.SendFile)
            return create_future(Payload(ret.toBytes()))
        
        # otherwise echo
        return create_future(payload)

    async def request_channel(self, payload: Payload) -> Tuple[Optional[Publisher], Optional[Subscriber]]:
        data = Msg.fromBytes(payload.data)
        return channel.create(data, is_service=True)
       
        
def start_service(name, dir, fdir):

    Config.service_dir = dir
    Config.files_dir = fdir

    port = 3000
    info = bonjour.register_service(name, port)
    name = info.name.split(".")[0]

    print("start service %s. service_dir=%s, files_dir=%s" % (name ,dir ,fdir)) 

    session_dir = os.path.join(Config.service_dir, 'sessions') 
    if os.path.isdir(session_dir):
        shutil.rmtree(session_dir, ignore_errors=True)

    app = Quart(name)

    @app.websocket("/")
    async def ws():
        await websocket_handler(handler_factory=Handler)

    # logging.basicConfig(level=logging.ERROR)
    
    while port < 9999:
        try:
            app.run('0.0.0.0', port=port)
            print("app end!")
            break
        except KeyboardInterrupt:
            break
        except:
            print("failed to run on port %d" % (port))
            port+=1
            # bonjour.unregister_service(info)
            info.port = port
            bonjour.update_service(info)

    bonjour.unregister_service(info)
    
