def test():
    print('Hi')