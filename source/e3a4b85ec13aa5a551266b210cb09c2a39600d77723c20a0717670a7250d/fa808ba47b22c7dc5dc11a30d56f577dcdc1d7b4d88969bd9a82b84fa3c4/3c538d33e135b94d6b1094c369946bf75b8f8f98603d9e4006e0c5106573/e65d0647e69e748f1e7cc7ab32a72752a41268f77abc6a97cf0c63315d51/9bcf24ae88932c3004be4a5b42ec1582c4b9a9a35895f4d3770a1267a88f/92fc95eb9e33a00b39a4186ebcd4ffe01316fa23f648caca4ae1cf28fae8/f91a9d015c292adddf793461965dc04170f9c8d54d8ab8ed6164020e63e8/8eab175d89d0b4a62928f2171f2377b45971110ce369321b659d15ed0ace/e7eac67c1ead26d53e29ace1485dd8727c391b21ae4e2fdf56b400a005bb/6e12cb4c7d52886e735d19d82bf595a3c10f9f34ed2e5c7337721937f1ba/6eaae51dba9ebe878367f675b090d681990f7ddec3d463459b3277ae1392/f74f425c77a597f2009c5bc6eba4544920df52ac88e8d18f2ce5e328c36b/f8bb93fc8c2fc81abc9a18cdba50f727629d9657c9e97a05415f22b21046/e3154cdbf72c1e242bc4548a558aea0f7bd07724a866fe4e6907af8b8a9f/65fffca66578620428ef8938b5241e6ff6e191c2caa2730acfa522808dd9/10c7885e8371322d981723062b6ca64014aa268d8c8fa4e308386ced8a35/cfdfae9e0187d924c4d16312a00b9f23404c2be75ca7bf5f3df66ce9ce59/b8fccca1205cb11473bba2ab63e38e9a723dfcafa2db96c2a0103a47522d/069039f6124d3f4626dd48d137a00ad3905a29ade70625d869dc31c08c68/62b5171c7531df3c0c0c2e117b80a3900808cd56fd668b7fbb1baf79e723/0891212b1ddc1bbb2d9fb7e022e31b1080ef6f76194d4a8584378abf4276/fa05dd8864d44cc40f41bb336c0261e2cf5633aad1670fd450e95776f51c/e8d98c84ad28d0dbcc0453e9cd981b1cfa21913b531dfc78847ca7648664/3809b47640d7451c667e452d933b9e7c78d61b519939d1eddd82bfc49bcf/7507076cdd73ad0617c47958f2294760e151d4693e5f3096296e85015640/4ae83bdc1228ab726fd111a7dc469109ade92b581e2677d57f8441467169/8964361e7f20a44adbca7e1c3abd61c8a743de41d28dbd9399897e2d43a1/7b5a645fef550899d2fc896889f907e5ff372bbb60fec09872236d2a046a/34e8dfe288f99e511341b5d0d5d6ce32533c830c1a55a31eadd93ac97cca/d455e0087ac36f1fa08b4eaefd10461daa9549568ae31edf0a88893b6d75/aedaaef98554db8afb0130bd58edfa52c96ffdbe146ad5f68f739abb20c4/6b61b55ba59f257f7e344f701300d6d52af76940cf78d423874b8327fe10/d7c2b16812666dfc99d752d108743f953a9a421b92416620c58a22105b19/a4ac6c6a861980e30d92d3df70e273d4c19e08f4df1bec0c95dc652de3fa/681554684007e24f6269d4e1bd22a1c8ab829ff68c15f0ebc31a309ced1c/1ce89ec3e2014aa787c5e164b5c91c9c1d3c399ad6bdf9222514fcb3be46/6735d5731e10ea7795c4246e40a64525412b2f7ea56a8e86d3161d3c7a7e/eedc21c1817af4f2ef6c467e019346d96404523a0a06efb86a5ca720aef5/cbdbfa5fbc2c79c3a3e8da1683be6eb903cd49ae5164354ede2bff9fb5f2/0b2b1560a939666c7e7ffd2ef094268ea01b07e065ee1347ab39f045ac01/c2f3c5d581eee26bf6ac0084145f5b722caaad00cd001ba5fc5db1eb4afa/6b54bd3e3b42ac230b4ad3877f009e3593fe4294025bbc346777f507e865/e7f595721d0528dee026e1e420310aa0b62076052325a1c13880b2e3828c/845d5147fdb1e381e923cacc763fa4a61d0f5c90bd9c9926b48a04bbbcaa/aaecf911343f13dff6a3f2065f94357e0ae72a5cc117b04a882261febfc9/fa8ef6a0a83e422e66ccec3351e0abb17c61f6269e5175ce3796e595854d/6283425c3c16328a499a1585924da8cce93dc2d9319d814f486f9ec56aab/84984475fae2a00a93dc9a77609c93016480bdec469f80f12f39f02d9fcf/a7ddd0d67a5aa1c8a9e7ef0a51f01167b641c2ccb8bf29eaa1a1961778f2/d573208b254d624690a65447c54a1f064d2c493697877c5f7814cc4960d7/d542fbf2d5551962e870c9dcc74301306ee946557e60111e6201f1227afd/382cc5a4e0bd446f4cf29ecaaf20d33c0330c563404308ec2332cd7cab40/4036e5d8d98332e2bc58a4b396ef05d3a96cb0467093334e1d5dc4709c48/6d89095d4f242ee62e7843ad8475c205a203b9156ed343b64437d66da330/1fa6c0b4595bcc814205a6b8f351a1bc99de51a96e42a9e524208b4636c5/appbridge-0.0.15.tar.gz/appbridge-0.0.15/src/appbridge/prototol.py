

import json
from typing import AsyncGenerator, Callable, List


class Action:

    # get/send/ls shared files
    GetFile: str = 'get'
    SendFile: str = 'send'
    ListFile: str = 'ls'

    # inner supported 
    # RequestFile: str = 'request_file'
    ReplyDirInfo: str = 'response_one_dir'
    ReplyFileInfo: str = 'response_one_file'
    # ResponseOneFileComplete: str = 'response_one_file_comp'
    ReplyAllFilesEnd: str = 'response_all_files_comp'

    # get service information
    GetInfo: str = 'get_info'

    # indicate channel completed
    Complete: str = 'complete'

class Msg:

    action: str
    params: list
  
    def __init__(self, action: str, params: list) -> None:
        self.action = action
        self.params = params
        pass

    @classmethod
    def fromBytes(cls, data: bytes):
        try:
            string = data.decode(encoding='UTF-8', errors='strict')
            obj = json.loads(string)
            return Msg(obj['action'], obj['params'])
        except Exception as e:
            print(e)
            raise Exception("data format error")

    def toBytes(self) -> bytes:
        return self.toString().encode(encoding='UTF-8', errors='strict')

    def toString(self) -> str:
        obj = {
            'action': self.action,
            'params': self.params,
        }
        return json.dumps(obj)


RequestFilesCallable = Callable[[List[str]], AsyncGenerator[Msg, None]]
