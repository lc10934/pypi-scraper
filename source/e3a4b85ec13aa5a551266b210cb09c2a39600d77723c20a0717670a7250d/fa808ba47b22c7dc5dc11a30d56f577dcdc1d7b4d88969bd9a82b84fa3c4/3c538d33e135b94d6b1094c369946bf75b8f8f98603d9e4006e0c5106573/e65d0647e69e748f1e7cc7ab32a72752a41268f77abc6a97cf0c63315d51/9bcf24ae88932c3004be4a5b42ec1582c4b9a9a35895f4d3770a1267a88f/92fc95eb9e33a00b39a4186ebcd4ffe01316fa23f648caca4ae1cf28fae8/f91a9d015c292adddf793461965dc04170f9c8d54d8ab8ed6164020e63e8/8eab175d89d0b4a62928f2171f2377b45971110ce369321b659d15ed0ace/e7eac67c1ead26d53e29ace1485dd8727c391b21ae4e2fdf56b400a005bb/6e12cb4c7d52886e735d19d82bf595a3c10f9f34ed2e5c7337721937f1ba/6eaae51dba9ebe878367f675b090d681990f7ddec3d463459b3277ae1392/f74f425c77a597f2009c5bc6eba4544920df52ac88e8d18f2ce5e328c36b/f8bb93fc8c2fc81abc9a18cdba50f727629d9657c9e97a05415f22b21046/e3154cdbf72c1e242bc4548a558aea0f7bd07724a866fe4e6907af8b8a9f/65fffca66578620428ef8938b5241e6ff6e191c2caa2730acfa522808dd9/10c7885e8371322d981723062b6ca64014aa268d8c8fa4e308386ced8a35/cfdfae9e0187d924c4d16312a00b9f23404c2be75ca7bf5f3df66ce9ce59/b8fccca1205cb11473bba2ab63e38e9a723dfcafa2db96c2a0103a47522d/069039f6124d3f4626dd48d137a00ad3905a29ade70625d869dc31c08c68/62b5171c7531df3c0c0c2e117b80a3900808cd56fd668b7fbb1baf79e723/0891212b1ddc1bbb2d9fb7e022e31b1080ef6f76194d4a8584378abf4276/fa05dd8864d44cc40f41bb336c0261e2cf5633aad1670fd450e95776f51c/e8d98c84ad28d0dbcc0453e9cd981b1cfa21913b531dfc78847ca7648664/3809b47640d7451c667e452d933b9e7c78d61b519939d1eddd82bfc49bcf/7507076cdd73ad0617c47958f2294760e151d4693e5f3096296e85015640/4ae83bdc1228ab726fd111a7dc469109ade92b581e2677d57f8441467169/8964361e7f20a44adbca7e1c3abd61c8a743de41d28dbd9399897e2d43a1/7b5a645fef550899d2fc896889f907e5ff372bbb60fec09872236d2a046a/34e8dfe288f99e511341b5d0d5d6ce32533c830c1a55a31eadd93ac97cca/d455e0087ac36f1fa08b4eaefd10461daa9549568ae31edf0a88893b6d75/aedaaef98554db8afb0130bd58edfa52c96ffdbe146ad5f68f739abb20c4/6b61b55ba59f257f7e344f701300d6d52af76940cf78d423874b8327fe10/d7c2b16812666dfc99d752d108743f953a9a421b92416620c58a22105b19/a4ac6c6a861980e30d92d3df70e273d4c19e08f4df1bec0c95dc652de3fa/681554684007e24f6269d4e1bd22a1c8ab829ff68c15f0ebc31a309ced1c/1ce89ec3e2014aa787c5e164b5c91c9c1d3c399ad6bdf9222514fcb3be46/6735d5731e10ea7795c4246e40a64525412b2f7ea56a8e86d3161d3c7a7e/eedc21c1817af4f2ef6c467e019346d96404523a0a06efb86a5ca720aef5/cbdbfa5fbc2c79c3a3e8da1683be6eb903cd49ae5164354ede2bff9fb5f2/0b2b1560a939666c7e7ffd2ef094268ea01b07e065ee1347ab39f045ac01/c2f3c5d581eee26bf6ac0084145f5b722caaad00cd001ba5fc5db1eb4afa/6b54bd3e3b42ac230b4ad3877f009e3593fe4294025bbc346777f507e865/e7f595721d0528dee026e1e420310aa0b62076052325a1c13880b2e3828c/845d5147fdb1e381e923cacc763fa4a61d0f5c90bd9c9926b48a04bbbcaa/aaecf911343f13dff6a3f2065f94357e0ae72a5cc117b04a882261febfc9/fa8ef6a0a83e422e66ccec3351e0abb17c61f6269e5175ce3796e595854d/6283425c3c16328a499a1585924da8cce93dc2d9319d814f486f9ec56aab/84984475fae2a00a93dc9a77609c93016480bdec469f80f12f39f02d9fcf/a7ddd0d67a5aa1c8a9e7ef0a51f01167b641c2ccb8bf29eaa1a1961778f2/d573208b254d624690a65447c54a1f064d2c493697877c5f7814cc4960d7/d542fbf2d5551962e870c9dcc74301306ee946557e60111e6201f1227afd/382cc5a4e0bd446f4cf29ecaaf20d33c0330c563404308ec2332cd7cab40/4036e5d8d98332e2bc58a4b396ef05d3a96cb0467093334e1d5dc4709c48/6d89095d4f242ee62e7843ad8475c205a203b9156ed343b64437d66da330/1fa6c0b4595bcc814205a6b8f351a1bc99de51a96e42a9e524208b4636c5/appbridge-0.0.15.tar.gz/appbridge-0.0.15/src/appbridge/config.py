

class Config:
    service_dir = ''
    files_dir = ''
    rename_save = False # rename file or dir when save
    
