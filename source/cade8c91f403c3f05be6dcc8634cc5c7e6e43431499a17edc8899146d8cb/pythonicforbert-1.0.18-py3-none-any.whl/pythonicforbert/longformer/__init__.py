# -*- coding: utf-8 -*-
# @Date    : 2021/11/22
# @Author  : xiaoguzai
# @Email   : 474551240@qq.com
# @File    : __init__.py.py
# @github  : https://github.com/xiaoguzai

from .loader_longformer import load_longformer_data
from .longformer import LongFormerConfig,LongFormer
