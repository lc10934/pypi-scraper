from typing import Any

TopicProfile = Any
