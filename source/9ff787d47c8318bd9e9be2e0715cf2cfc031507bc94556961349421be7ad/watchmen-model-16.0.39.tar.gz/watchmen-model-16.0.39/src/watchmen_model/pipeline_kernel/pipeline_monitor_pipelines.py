from typing import List

from watchmen_model.admin import Pipeline, Topic


# noinspection PyUnusedLocal
def ask_pipeline_monitor_pipelines(topics: List[Topic]) -> List[Pipeline]:
	# TODO define all pipeline monitor pipelines
	return []
