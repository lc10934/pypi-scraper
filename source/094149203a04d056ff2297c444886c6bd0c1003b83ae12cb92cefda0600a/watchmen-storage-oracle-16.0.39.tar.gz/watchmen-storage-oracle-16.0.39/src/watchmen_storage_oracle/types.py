from typing import Any

SQLAlchemyStatement = Any
