class PipelineKernelException(Exception):
	pass
