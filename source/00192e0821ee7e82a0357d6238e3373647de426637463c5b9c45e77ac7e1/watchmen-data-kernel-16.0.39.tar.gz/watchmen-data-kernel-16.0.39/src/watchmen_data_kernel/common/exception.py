class DataKernelException(Exception):
	pass
