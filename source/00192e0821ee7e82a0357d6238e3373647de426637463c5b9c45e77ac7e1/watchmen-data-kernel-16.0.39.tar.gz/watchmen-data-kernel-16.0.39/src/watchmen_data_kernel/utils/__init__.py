from .variable_helper import MightAVariable, parse_function_in_variable, parse_variable
