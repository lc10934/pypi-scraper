#. Go to *Inventory > Settings*.
#. Activate the option "Units of Measure".
#. Follow the steps of stock_picking_product_barcode_report with a product that have set
   secondary units.
