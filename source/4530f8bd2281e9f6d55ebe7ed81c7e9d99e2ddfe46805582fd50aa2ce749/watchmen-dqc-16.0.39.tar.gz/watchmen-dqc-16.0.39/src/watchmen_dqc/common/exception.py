class DqcException(Exception):
	pass
