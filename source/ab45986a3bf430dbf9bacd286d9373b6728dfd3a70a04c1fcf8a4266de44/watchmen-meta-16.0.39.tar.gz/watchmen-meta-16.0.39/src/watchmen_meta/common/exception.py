class InitialMetaAppException(Exception):
	pass
