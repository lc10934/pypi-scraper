class RestAppException(Exception):
	pass


class InitialRestAppException(RestAppException):
	pass
