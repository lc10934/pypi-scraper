class KACLException(Exception):
    pass