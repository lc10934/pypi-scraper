#. You can define other reports to print checking the option 'Barcode Label' on report
   record.
#. You can select a default report on 'Settings > Inventory > Barcode format > Default
   template for barcode labels'. There will only appear the reports with the option
   'Barcode Label' checked.
#. Go to 'Settings > Inventory > Barcode format' and select on 'Method to choose the
   barcode formating' the value 'Display GS1_128 format for barcodes' or let it blank
   for normal use of barcodes on Odoo.
