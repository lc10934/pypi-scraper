This module allows you to select how many copies of barcode labels do you want
to print.
