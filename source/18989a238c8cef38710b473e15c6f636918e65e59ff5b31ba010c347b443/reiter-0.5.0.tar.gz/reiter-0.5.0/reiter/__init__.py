"""Gives users direct access to the class."""
from reiter.reiter import reiter
