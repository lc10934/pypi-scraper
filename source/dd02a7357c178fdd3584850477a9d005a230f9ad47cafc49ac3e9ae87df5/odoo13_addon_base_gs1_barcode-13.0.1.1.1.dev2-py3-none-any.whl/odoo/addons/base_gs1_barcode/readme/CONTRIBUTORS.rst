* `Numérigraphe <http://numerigraphe.com>`_:

  * Lionel Sausin <ls@numerigraphe.fr>

* `Therp <http://therp.nl>`_:

  * Stefan Rijnhart <stefan@therp.nl>

* `Tecnativa <https://www.tecnativa.com>`_:

  * Sergio Teruel <sergio.teruel@tecnativa.com>
