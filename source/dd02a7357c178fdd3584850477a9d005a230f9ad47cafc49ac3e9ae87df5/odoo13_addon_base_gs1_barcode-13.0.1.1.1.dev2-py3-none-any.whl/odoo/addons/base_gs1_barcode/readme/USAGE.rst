You can use the functionality provided by this module in your own customization
or other OCA modules.
