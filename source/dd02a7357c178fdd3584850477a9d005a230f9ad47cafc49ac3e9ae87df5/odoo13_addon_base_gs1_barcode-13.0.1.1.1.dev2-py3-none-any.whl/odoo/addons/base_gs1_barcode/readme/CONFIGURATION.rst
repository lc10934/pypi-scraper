To configure the Application Identifiers and the associated data types, go to
*Sales -> Settings -> Product Categories & Attributes ->
GS1-128/GS1-Datamatrix Decoding*

You can configure the barcode string separator and prefix in the System
parameters. Use *None* to indicate a null prefix.
