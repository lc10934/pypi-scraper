# Security Policy

## Reporting a Vulnerability

If you've found a security vulnerability in SeleniumBase, (or a dependency we use), please open an issue.

[github.com/seleniumbase/SeleniumBase/issues](https://github.com/seleniumbase/SeleniumBase/issues)

Please describe the results you're seeing, and the results you're expecting.
