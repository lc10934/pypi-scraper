<h2><img src="https://seleniumbase.io/img/logo6.png" title="SeleniumBase" width="32" /> CHANGELOG</h2>

<h3>See: [SeleniumBase/releases](https://github.com/seleniumbase/SeleniumBase/releases)</h3>
