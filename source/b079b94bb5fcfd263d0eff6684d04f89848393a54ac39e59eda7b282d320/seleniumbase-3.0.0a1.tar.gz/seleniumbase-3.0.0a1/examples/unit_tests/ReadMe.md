### <img src="https://seleniumbase.io/img/sb_icon.png" title="SeleniumBase" width="20" /> pytest-specific unit tests

The tests in this folder are for basic verification of the SeleniumBase framework with pytest.
