# Desired capabilities example file for generic macOS Grid nodes

capabilities = {
    "platformName": "MAC",
    "browserVersion": "latest",
}
