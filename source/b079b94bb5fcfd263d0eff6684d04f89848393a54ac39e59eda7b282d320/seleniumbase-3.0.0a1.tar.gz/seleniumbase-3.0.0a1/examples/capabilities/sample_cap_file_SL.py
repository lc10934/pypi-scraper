# Desired capabilities example file for Sauce Labs
# Generate from https://wiki.saucelabs.com/display/DOCS/Platform+Configurator#/
capabilities = {
    "browserName": "chrome",
    "browserVersion": "latest",
    "platformName": "macOS 10.14",
    "sauce:options": {},
}
