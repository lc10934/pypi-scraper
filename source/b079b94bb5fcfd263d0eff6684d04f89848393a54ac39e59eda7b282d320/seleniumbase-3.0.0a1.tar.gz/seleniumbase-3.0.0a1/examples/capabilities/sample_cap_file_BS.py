# Desired capabilities example file for BrowserStack
# Generate from https://www.browserstack.com/automate/capabilities
desired_cap = {
    "os": "OS X",
    "os_version": "Mojave",
    "browser": "Chrome",
    "browser_version": "latest",
    "browserstack.local": "false",
    "browserstack.selenium_version": "3.141.59",
}
