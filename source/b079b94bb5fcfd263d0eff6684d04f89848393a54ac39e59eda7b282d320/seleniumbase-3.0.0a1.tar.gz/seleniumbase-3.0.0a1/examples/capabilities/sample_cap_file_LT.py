# Desired capabilities example file for LambdaTest
# Generate from https://www.lambdatest.com/capabilities-generator/
capabilities = {
    "build": "your build name",
    "name": "your test name",
    "platform": "Windows 11",
    "browserName": "Chrome",
    "version": "100.0",
}
