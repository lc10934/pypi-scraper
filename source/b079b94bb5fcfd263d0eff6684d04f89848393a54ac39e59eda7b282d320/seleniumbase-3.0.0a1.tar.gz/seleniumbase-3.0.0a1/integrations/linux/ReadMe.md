## Running SeleniumBase on Debian GNU/Linux

Files in this folder are currently used with the [Jenkins on Microsoft Azure setup instructions for SeleniumBase](https://github.com/seleniumbase/SeleniumBase/blob/master/integrations/azure/jenkins/ReadMe.md), as well as with the [Jenkins on Google Cloud setup instructions for SeleniumBase](https://github.com/seleniumbase/SeleniumBase/blob/master/integrations/google_cloud/ReadMe.md). You can also use these files standalone with any Ubuntu/Debian GNU/Linux machine.
