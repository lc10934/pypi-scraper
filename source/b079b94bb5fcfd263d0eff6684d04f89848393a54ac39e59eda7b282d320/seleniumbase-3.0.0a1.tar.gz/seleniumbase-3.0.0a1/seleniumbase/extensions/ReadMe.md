[<img src="https://seleniumbase.io/cdn/img/sb_text_f.png" title="SeleniumBase" align="center" width="360">](https://github.com/seleniumbase/SeleniumBase/blob/master/README.md)

<h2><img src="https://seleniumbase.io/img/logo6.png" title="SeleniumBase" width="30" /> SeleniumBase browser extension storage</h2>

**The List:**
* ad_block.zip => This extension blocks ad content from appearing on any website.
* disable_csp.zip => This extension disables a website's Content-Security-Policy.
* recorder.zip => Save browser actions to sessionStorage with good CSS selectors.
