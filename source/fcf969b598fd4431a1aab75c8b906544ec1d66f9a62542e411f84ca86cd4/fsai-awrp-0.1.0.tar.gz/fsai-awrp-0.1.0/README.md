# fsai-awrp
Library that helps an application report progress to Argo Workflows.
